//
//  Optionalcell.swift
//  BaoBeo
//
//  Created by anhtdt on 24/04/2022.
//

import UIKit

class Optionalcell: UITableViewCell {

    @IBOutlet weak var detailLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
