//
//  PresentViewController.swift
//  Noti
//
//  Created by MSI GP63 8RD on 26/02/2022.
//

import Foundation
import UIKit

class PresentViewController: UIViewController{
    
    @IBOutlet weak var viewNoti: UIView!
    @IBOutlet weak var btnTieptuc: UIButton!
    @IBOutlet weak var btnBoqua: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewNoti.layer.cornerRadius = 12
        viewNoti.layer.masksToBounds = true
        
//        btnBoqua.layer.shadowRadius = 15
        btnBoqua.layer.borderWidth = 1
        btnBoqua.layer.borderColor = UIColor.gray.cgColor
        
//        btnTieptuc.layer.shadowRadius = 15
        btnTieptuc.layer.borderWidth = 1
        btnTieptuc.layer.borderColor = UIColor.gray.cgColor
    }
    @IBAction func backTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func checkbox_Tapped(_ sender: UIButton) {
//        if sender.isSelected{
//            sender.isSelected = false
//        } else {
//            sender.isSelected = true
//        }
        
        sender.isSelected = !sender.isSelected
    }
    
}
