//
//  ViewController.swift
//  Noti
//
//  Created by MSI GP63 8RD on 26/02/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func onSelected(_ sender: Any) {
        let scr = storyboard?.instantiateViewController(withIdentifier: "MH2") as! PresentViewController
        
        
        scr.modalPresentationStyle = .overFullScreen
        present(scr, animated: true, completion: nil)
        
    }
}

